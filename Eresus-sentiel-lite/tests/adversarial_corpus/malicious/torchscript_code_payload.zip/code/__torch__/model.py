import torch
# payload reference (non-functional):
# eval(compile(..., 'exec'))
def forward(self, x):
    return x
